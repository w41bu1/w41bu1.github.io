<?php
function say_hello() {
    echo "Hello from PEAR package!\n";
}
?>

